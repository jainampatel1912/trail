// File name: server.mjs
// Student Name: Jainam Patel
// StudentID: 200612850
// Date: January 31, 2025

import dotenv from 'dotenv';
import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';

dotenv.config();
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Database connection
const MONGO_URI = process.env.MONGO_URI || 'mongodb+srv://jvpatel2590:JainamP1912@jainam.eiuc8.mongodb.net/recipesDB?retryWrites=true&w=majority';
mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => console.error("MongoDB connection error", err));

// Recipe model
const RecipeSchema = new mongoose.Schema({
  title: String,
  ingredients: [String],
  instructions: String
});
const Recipe = mongoose.model('Recipe', RecipeSchema);

// Routes
const router = express.Router();

// Root route
app.get('/', async (req, res) => {
  try {
    const recipes = await Recipe.find().limit(10);
    res.json({ message: "Welcome to the Recipes API!", availableEndpoints: ["/api/recipes", "/api/recipes/random"], sampleRecipes: recipes });
  } catch (error) {
    res.status(500).json({ error: "Server Error" });
  }
});

// Fetch all recipes
router.get('/recipes', async (req, res) => {
  try {
    const recipes = await Recipe.find().limit(20);
    res.json(recipes);
  } catch (error) {
    res.status(500).json({ error: "Server Error" });
  }
});

// Fetch a random recipe
router.get('/recipes/random', async (req, res) => {
  try {
    const count = await Recipe.countDocuments();
    const randomIndex = Math.floor(Math.random() * count);
    const randomRecipe = await Recipe.findOne().skip(randomIndex);
    res.json(randomRecipe);
  } catch (error) {
    res.status(500).json({ error: "Server Error" });
  }
});

// Use the router
app.use('/api', router);

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
